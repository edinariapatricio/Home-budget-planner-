import React from 'react';

const AdminDashboard = () => (
  <div>
    <h1>Admin Dashboard</h1>
  </div>
);

export default AdminDashboard;
